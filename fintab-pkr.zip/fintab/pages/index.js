import { useState, useEffect, useRef } from "react";
import Head from "next/head";
import Script from "next/script";

// ── Constants ────────────────────────────────────────────────────────────────
const RATE = 278.5;
const pkr = (usd) => Math.round(usd * RATE);

function fmt(n) {
  if (n >= 10000000) return "Rs " + (n / 10000000).toFixed(2) + " cr";
  if (n >= 100000) return "Rs " + (n / 100000).toFixed(1) + " lac";
  if (n >= 1000) return "Rs " + Math.round(n / 1000) + "k";
  return "Rs " + Math.round(n).toLocaleString("en-PK");
}
function fmtFull(n) {
  return "Rs " + Math.round(n).toLocaleString("en-PK");
}

const CATEGORIES = {
  "Food & dining":  { icon: "🍽️", color: "#1D9E75", bg: "#E1F5EE" },
  Housing:          { icon: "🏠", color: "#185FA5", bg: "#E6F1FB" },
  Transport:        { icon: "🚗", color: "#BA7517", bg: "#FAEEDA" },
  Entertainment:    { icon: "📺", color: "#533B89", bg: "#EEEDFE" },
  Health:           { icon: "❤️", color: "#A32D2D", bg: "#FCEBEB" },
  Shopping:         { icon: "🛍️", color: "#993556", bg: "#FBEAF0" },
  Other:            { icon: "•••", color: "#5F5E5A", bg: "#F1EFE8" },
};

const NW_LABELS = ["Jul'24","Aug","Sep","Oct","Nov","Dec","Jan'25","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec","Jan'26","Feb","Mar","Apr","May","Jun'26"];
const NW_USD =   [34140,35820,36400,37100,38200,39500,38800,40200,43440,41900,42800,43600,44100,44800,45200,45800,46300,47000,46200,47100,48320,47800,48000,48320];
const INV_USD =  [19200,20100,20600,21200,22400,23900,23100,24500,27200,25800,26400,27000,27500,28100,28400,28900,29500,30200,29300,30100,31240,30800,31000,31240];
const CASH_USD = [8100,8500,8600,8700,8900,9200,9000,9400,9800,9400,9700,9900,9900,10000,10000,10200,10100,10200,10200,10400,10480,10400,10400,10480];
const NW_PKR   = NW_USD.map(pkr);
const INV_PKR  = INV_USD.map(pkr);
const CASH_PKR = CASH_USD.map(pkr);

const MILESTONES = [
  { label: "Rs 70 lac net worth",    date: "Jan 2025",       done: true },
  { label: "Rs 1.0 crore net worth", date: "Mar 2025",       done: true },
  { label: "Rs 1.35 crore net worth",date: "Jun 2026",       done: true },
  { label: "Rs 1.5 crore net worth", date: "Sep 2026 (est.)",done: false },
  { label: "Rs 2.0 crore net worth", date: "Feb 2027 (est.)",done: false },
];

const HOLDINGS = [
  { ticker:"VTI", name:"Vanguard Total Market",  alloc:"35%", valuePkr:pkr(10934), delta:"+1.2%", up:true },
  { ticker:"AAPL",name:"Apple Inc.",              alloc:"12%", valuePkr:pkr(3748),  delta:"+2.8%", up:true },
  { ticker:"BND", name:"Vanguard Bond ETF",       alloc:"11%", valuePkr:pkr(3436),  delta:"-0.1%", up:false },
  { ticker:"QQQ", name:"Invesco Nasdaq-100",      alloc:"18%", valuePkr:pkr(5623),  delta:"+3.5%", up:true },
  { ticker:"MSFT",name:"Microsoft Corp.",         alloc:"10%", valuePkr:pkr(3124),  delta:"+0.9%", up:true },
  { ticker:"CASH",name:"Money market",            alloc:"7%",  valuePkr:pkr(2187),  delta:"0.0%",  up:true },
];

const INIT_TX = [
  { id:1, name:"Grocery run",       cat:"Food & dining", amount:pkr(64.20), date:"2026-06-17" },
  { id:2, name:"Monthly rent",      cat:"Housing",       amount:pkr(950),   date:"2026-06-01" },
  { id:3, name:"Rickshaw / Careem", cat:"Transport",     amount:pkr(18.50), date:"2026-06-16" },
  { id:4, name:"Netflix",           cat:"Entertainment", amount:pkr(15.99), date:"2026-06-10" },
  { id:5, name:"Pharmacy",          cat:"Health",        amount:pkr(32.40), date:"2026-06-15" },
  { id:6, name:"Café lunch",        cat:"Food & dining", amount:pkr(22.00), date:"2026-06-17" },
  { id:7, name:"Gym membership",    cat:"Health",        amount:pkr(49.00), date:"2026-06-05" },
  { id:8, name:"Daraz order",       cat:"Shopping",      amount:pkr(87.30), date:"2026-06-12" },
  { id:9, name:"Bus pass",          cat:"Transport",     amount:pkr(45.00), date:"2026-06-01" },
  { id:10,name:"Dinner out",        cat:"Food & dining", amount:pkr(78.50), date:"2026-06-14" },
];

const BUDGET_LIMITS = {
  "Food & dining": pkr(600), Housing: pkr(1000), Transport: pkr(200),
  Entertainment: pkr(150), Health: pkr(200), Shopping: pkr(300),
};

// ── Helpers ──────────────────────────────────────────────────────────────────
function calcSpent(transactions) {
  const s = {};
  Object.keys(BUDGET_LIMITS).forEach((k) => (s[k] = 0));
  transactions.forEach((t) => { if (s[t.cat] !== undefined) s[t.cat] += t.amount; });
  return s;
}

function downloadCSV(filename, csv) {
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

// ── Sub-components ────────────────────────────────────────────────────────────
function MetricCard({ label, value, delta, deltaUp }) {
  return (
    <div style={{ background:"var(--bg-secondary)", borderRadius:"var(--radius-md)", padding:"1rem" }}>
      <div style={{ fontSize:12, color:"var(--text-secondary)", marginBottom:6 }}>{label}</div>
      <div style={{ fontSize:20, fontWeight:500 }}>{value}</div>
      {delta && (
        <div style={{ fontSize:12, marginTop:4, color: deltaUp === false ? "#A32D2D" : deltaUp ? "#0F6E56" : "var(--text-secondary)" }}>
          {delta}
        </div>
      )}
    </div>
  );
}

function TxItem({ t }) {
  const c = CATEGORIES[t.cat] || CATEGORIES["Other"];
  return (
    <div style={{ display:"flex", alignItems:"center", gap:10, padding:"8px 0", borderBottom:"0.5px solid var(--border-light)" }}>
      <div style={{ width:32, height:32, borderRadius:8, background:c.bg, color:c.color, display:"flex", alignItems:"center", justifyContent:"center", fontSize:15, flexShrink:0 }}>{c.icon}</div>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontSize:13, fontWeight:500, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{t.name}</div>
        <div style={{ fontSize:11, color:"var(--text-secondary)" }}>{t.cat}</div>
      </div>
      <div style={{ textAlign:"right" }}>
        <div style={{ fontSize:13, fontWeight:500 }}>-{fmtFull(t.amount)}</div>
        <div style={{ fontSize:11, color:"var(--text-tertiary)" }}>{t.date.slice(5).replace("-", "/")}</div>
      </div>
    </div>
  );
}

function BudgetBar({ cat, spent, limit, showPct = false }) {
  const pct = Math.min(100, Math.round((spent / limit) * 100));
  const color = pct > 90 ? "#E24B4A" : pct > 75 ? "#EF9F27" : "#1D9E75";
  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", marginBottom:5 }}>
        <span style={{ fontSize:13, fontWeight:500 }}>{cat}</span>
        <span style={{ fontSize:12, color:"var(--text-secondary)" }}>
          {fmt(spent)}/{fmt(limit)}{showPct ? ` · ${pct}%` : ""}
        </span>
      </div>
      <div style={{ height:6, background:"var(--bg-secondary)", borderRadius:3, overflow:"hidden" }}>
        <div style={{ height:"100%", width:`${pct}%`, background:color, borderRadius:3, transition:"width .3s" }} />
      </div>
    </div>
  );
}

// ── Views ─────────────────────────────────────────────────────────────────────
function Dashboard({ transactions, spent, goTo }) {
  const totalSpend = Object.values(spent).reduce((a, b) => a + b, 0);
  useEffect(() => {
    if (!window.Chart) return;
    const destroy = (id) => { const c = window._charts?.[id]; if (c) c.destroy(); };
    const save = (id, inst) => { window._charts = window._charts || {}; window._charts[id] = inst; };
    const dark = matchMedia("(prefers-color-scheme: dark)").matches;
    const tc = dark ? "rgba(255,255,255,0.4)" : "rgba(0,0,0,0.35)";
    const gc = dark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)";

    destroy("spend"); destroy("cat");
    save("spend", new window.Chart(document.getElementById("spendChart"), {
      type:"bar",
      data:{ labels:Array.from({length:17},(_,i)=>i+1), datasets:[{ label:"Rs", data:Array.from({length:17},()=>Math.round(pkr(50+Math.random()*200))), backgroundColor:"#1D9E75", borderRadius:4, borderWidth:0 }] },
      options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}}, scales:{ x:{ticks:{color:tc,font:{size:10},maxRotation:0,autoSkip:true,maxTicksLimit:9},grid:{display:false}}, y:{ticks:{color:tc,font:{size:10},callback:v=>"Rs "+Math.round(v/1000)+"k"},grid:{color:gc}} } }
    }));
    save("cat", new window.Chart(document.getElementById("catChart"), {
      type:"doughnut",
      data:{ labels:["Housing","Food & dining","Transport","Entertainment","Health","Other"], datasets:[{ data:[35,28,12,10,8,7], backgroundColor:["#185FA5","#1D9E75","#BA7517","#533B89","#A32D2D","#888780"], borderWidth:0 }] },
      options:{ responsive:true, maintainAspectRatio:false, cutout:"62%", plugins:{legend:{display:false}} }
    }));
  }, []);

  const alerts = [];
  Object.keys(BUDGET_LIMITS).forEach((cat) => {
    const pct = (spent[cat] / BUDGET_LIMITS[cat]) * 100;
    if (pct >= 100) alerts.push({ type:"warn", msg:`${cat} budget exceeded — ${fmt(spent[cat] - BUDGET_LIMITS[cat])} over limit` });
    else if (pct >= 80) alerts.push({ type:"warn", msg:`${cat} at ${Math.round(pct)}% of budget` });
  });
  alerts.push({ type:"info", msg:"Next salary credit on Jun 25 — 8 days away" });
  alerts.push({ type:"success", msg:"Savings target met for June — shabash! 🎉" });

  const alertBg = { warn:"var(--amber-bg)", info:"var(--blue-bg)", success:"var(--green-bg)" };
  const alertColor = { warn:"var(--amber)", info:"var(--blue)", success:"var(--green-dark)" };

  const recent = [...transactions].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5);

  return (
    <>
      <div style={grid(4)}>
        <MetricCard label="Net worth" value="Rs 1.35 cr" delta="↑ +Rs 5.12 lac this month" deltaUp={true} />
        <MetricCard label="Monthly spend" value={fmt(totalSpend)} delta="↑ +Rs 66,840 vs last month" deltaUp={false} />
        <MetricCard label="Savings rate" value="22%" delta="+3pts vs target" deltaUp={true} />
        <MetricCard label="Investments" value="Rs 87.0 lac" delta="+4.2% MTD" deltaUp={true} />
      </div>
      <div style={grid(2)}>
        <Card title="Spend this month" badge="Jun 2026" badgeColor="#BA7517" badgeBg="#FAEEDA">
          <div style={{height:200,marginTop:8}}><canvas id="spendChart"/></div>
        </Card>
        <Card title="Category breakdown">
          <div style={{height:200,marginTop:8}}><canvas id="catChart"/></div>
        </Card>
      </div>
      <div style={grid(2)}>
        <Card title="Recent transactions" action={<Btn small onClick={()=>goTo("expenses")}>View all</Btn>}>
          {recent.map(t=><TxItem key={t.id} t={t}/>)}
        </Card>
        <Card title="Budget status" action={<Btn small onClick={()=>goTo("budget")}>Manage</Btn>}>
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            {Object.keys(BUDGET_LIMITS).slice(0,4).map(cat=>(
              <BudgetBar key={cat} cat={cat} spent={spent[cat]||0} limit={BUDGET_LIMITS[cat]}/>
            ))}
          </div>
        </Card>
      </div>
      <Card title="Active alerts">
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {alerts.map((a,i)=>(
            <div key={i} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",borderRadius:"var(--radius-md)",fontSize:13,background:alertBg[a.type],color:alertColor[a.type]}}>
              {a.type==="warn"?"⚠️":a.type==="success"?"✅":"ℹ️"} {a.msg}
            </div>
          ))}
        </div>
      </Card>
    </>
  );
}

function NetWorth() {
  const [range, setRange] = useState(6);
  useEffect(() => {
    if (!window.Chart) return;
    const dark = matchMedia("(prefers-color-scheme: dark)").matches;
    const tc = dark ? "rgba(255,255,255,0.4)" : "rgba(0,0,0,0.35)";
    const gc = dark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.05)";
    const sl = (arr) => arr.slice(-range);
    const labels = sl(NW_LABELS), nwD = sl(NW_PKR), invD = sl(INV_PKR), cashD = sl(CASH_PKR);
    const changes = nwD.map((v,i)=>i===0?0:Math.round(v-nwD[i-1]));
    const fmtK = v => { const abs=Math.abs(v); if(abs>=100000) return (v>=0?"+":"-")+"Rs "+(abs/100000).toFixed(1)+"L"; return (v>=0?"+":"")+Math.round(v/1000)+"k"; };

    ["nwLine","nwBar","wPie"].forEach(id=>{ const c=window._charts?.[id]; if(c)c.destroy(); });
    window._charts = window._charts || {};
    window._charts.nwLine = new window.Chart(document.getElementById("nwLine"),{
      type:"line",
      data:{labels,datasets:[
        {label:"Net worth",data:nwD,borderColor:"#1D9E75",borderWidth:2,pointRadius:3,pointBackgroundColor:"#1D9E75",tension:.35,fill:false},
        {label:"Investments",data:invD,borderColor:"#185FA5",borderWidth:1.5,borderDash:[4,3],pointRadius:2,pointBackgroundColor:"#185FA5",tension:.35,fill:false},
        {label:"Cash",data:cashD,borderColor:"#BA7517",borderWidth:1.5,borderDash:[2,4],pointRadius:2,pointBackgroundColor:"#BA7517",tension:.35,fill:false}
      ]},
      options:{responsive:true,maintainAspectRatio:false,interaction:{mode:"index",intersect:false},plugins:{legend:{display:false},tooltip:{callbacks:{label:ctx=>`${ctx.dataset.label}: ${fmt(ctx.parsed.y)}`}}},scales:{x:{ticks:{color:tc,font:{size:11},maxRotation:0,autoSkip:true,maxTicksLimit:8},grid:{display:false}},y:{ticks:{color:tc,font:{size:10},callback:v=>fmt(v)},grid:{color:gc}}}}
    });
    window._charts.nwBar = new window.Chart(document.getElementById("nwBar"),{
      type:"bar",
      data:{labels,datasets:[{label:"Change",data:changes,backgroundColor:changes.map(v=>v>=0?"#1D9E75":"#E24B4A"),borderRadius:3,borderWidth:0}]},
      options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{ticks:{color:tc,font:{size:10},maxRotation:0,autoSkip:true,maxTicksLimit:6},grid:{display:false}},y:{ticks:{color:tc,font:{size:10},callback:fmtK},grid:{color:gc}}}}
    });
    window._charts.wPie = new window.Chart(document.getElementById("wPie"),{
      type:"doughnut",
      data:{labels:["Investments","Cash","Real assets"],datasets:[{data:[65,17,18],backgroundColor:["#185FA5","#1D9E75","#BA7517"],borderWidth:0}]},
      options:{responsive:true,maintainAspectRatio:false,cutout:"60%",plugins:{legend:{display:false}}}
    });
  }, [range]);

  return (
    <>
      <div style={grid(4)}>
        <MetricCard label="Current net worth" value="Rs 1.35 cr" delta="+Rs 39.5 lac YTD" deltaUp={true}/>
        <MetricCard label="12-month growth" value="+41.5%" delta="vs 8.1% market avg" deltaUp={true}/>
        <MetricCard label="Best month" value="Mar 2026" delta="+Rs 9.02 lac gained" deltaUp={true}/>
        <MetricCard label="Projected Dec 2026" value="Rs 1.64 cr" delta="At current rate" deltaUp={true}/>
      </div>
      <Card title="Net worth over time" action={
        <div style={{display:"flex",gap:5}}>
          {[6,12,24].map(r=>(
            <button key={r} onClick={()=>setRange(r)} style={{padding:"4px 10px",fontSize:11,borderRadius:"var(--radius-sm)",border:"0.5px solid var(--border)",background:range===r?"#1D9E75":"var(--bg-primary)",color:range===r?"#fff":"var(--text-secondary)",cursor:"pointer"}}>{r}M</button>
          ))}
        </div>
      }>
        <div style={{display:"flex",gap:16,marginBottom:8,fontSize:12,color:"var(--text-secondary)"}}>
          <span>🟩 Net worth</span><span>🔵 Investments</span><span>🟧 Cash</span>
        </div>
        <div style={{height:260,marginTop:8}}><canvas id="nwLine"/></div>
      </Card>
      <div style={grid(2)}>
        <Card title="Monthly change"><div style={{height:160,marginTop:8}}><canvas id="nwBar"/></div></Card>
        <Card title="Wealth breakdown — Jun 2026"><div style={{height:160,marginTop:8}}><canvas id="wPie"/></div></Card>
      </div>
      <Card title="Milestone tracker">
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {MILESTONES.map((m,i)=>(
            <div key={i} style={{display:"flex",alignItems:"center",gap:10}}>
              <div style={{width:20,height:20,borderRadius:"50%",background:m.done?"#1D9E75":"var(--bg-secondary)",border:`1.5px solid ${m.done?"#1D9E75":"var(--border)"}`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontSize:11,color:"#fff"}}>{m.done?"✓":""}</div>
              <span style={{flex:1,fontSize:13,color:m.done?"var(--text-primary)":"var(--text-secondary)"}}>{m.label}</span>
              <span style={{fontSize:12,color:m.done?"#0F6E56":"var(--text-tertiary)"}}>{m.date}</span>
            </div>
          ))}
        </div>
      </Card>
    </>
  );
}

function Expenses({ transactions, setTransactions }) {
  const [showAdd, setShowAdd] = useState(false);
  const [filter, setFilter] = useState("");
  const [form, setForm] = useState({ name:"", amount:"", cat:"Food & dining", date:new Date().toISOString().slice(0,10) });

  const filtered = filter ? transactions.filter(t=>t.cat===filter) : transactions;
  const sorted = [...filtered].sort((a,b)=>b.date.localeCompare(a.date));

  function addTx() {
    if (!form.name || !form.amount || !form.date) return;
    setTransactions(prev=>[{ id:Date.now(), name:form.name, cat:form.cat, amount:parseFloat(form.amount), date:form.date }, ...prev]);
    setForm({ name:"", amount:"", cat:"Food & dining", date:new Date().toISOString().slice(0,10) });
    setShowAdd(false);
  }

  return (
    <>
      {showAdd && (
        <Card title="Add expense" action={<Btn small onClick={()=>setShowAdd(false)}>Cancel</Btn>}>
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            <div style={grid(2)}>
              <div><Label>Description</Label><Input placeholder="e.g. Lunch at dhaba" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))}/></div>
              <div><Label>Amount (Rs)</Label><Input type="number" placeholder="0" value={form.amount} onChange={e=>setForm(f=>({...f,amount:e.target.value}))}/></div>
            </div>
            <div style={grid(2)}>
              <div><Label>Category</Label>
                <select style={inputStyle} value={form.cat} onChange={e=>setForm(f=>({...f,cat:e.target.value}))}>
                  {Object.keys(CATEGORIES).map(c=><option key={c}>{c}</option>)}
                </select>
              </div>
              <div><Label>Date</Label><Input type="date" value={form.date} onChange={e=>setForm(f=>({...f,date:e.target.value}))}/></div>
            </div>
            <Btn primary onClick={addTx}>+ Add transaction</Btn>
          </div>
        </Card>
      )}
      {!showAdd && <Btn primary onClick={()=>setShowAdd(true)}>+ Add expense</Btn>}
      <Card title="All transactions" action={
        <select style={{...inputStyle,fontSize:12,padding:"3px 8px",height:"auto"}} value={filter} onChange={e=>setFilter(e.target.value)}>
          <option value="">All categories</option>
          {Object.keys(CATEGORIES).map(c=><option key={c}>{c}</option>)}
        </select>
      }>
        {sorted.map(t=><TxItem key={t.id} t={t}/>)}
      </Card>
    </>
  );
}

function Budget({ spent }) {
  const [thresholds, setThresholds] = useState({ "Food & dining":80, Housing:90, Transport:75, Entertainment:80, Health:75, Shopping:80 });
  const totalSpent = Object.values(spent).reduce((a,b)=>a+b,0);
  const totalLimit = Object.values(BUDGET_LIMITS).reduce((a,b)=>a+b,0);

  return (
    <>
      <div style={grid(4)}>
        <MetricCard label="Total budgeted" value={fmt(totalLimit)}/>
        <MetricCard label="Total spent" value={fmt(totalSpent)}/>
        <MetricCard label="Remaining" value={fmt(totalLimit-totalSpent)} delta="Available" deltaUp={true}/>
        <MetricCard label="Days left" value="13"/>
      </div>
      <Card title="Budget categories">
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          {Object.keys(BUDGET_LIMITS).map(cat=>(
            <BudgetBar key={cat} cat={cat} spent={spent[cat]||0} limit={BUDGET_LIMITS[cat]} showPct/>
          ))}
        </div>
      </Card>
      <Card title="Alert thresholds">
        <p style={{fontSize:13,color:"var(--text-secondary)",marginBottom:12}}>Get notified when you reach a % of your budget limit.</p>
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {Object.keys(thresholds).map(cat=>(
            <div key={cat} style={{display:"flex",alignItems:"center",gap:12}}>
              <span style={{fontSize:13,flex:1}}>{cat}</span>
              <input type="range" min={50} max={100} step={5} value={thresholds[cat]} style={{flex:2}}
                onChange={e=>setThresholds(t=>({...t,[cat]:+e.target.value}))}/>
              <span style={{fontSize:12,minWidth:36,textAlign:"right"}}>{thresholds[cat]}%</span>
            </div>
          ))}
        </div>
      </Card>
    </>
  );
}

function Investments() {
  useEffect(()=>{
    if(!window.Chart)return;
    const c=window._charts?.alloc; if(c)c.destroy();
    window._charts=window._charts||{};
    window._charts.alloc=new window.Chart(document.getElementById("allocChart"),{
      type:"doughnut",
      data:{labels:["ETFs","Stocks","Bonds","Cash"],datasets:[{data:[55,28,11,6],backgroundColor:["#1D9E75","#185FA5","#BA7517","#888780"],borderWidth:0}]},
      options:{responsive:true,maintainAspectRatio:false,cutout:"65%",plugins:{legend:{display:false}}}
    });
  },[]);
  return (
    <>
      <div style={grid(4)}>
        <MetricCard label="Portfolio value" value="Rs 87.0 lac" delta="+4.2% MTD" deltaUp={true}/>
        <MetricCard label="Today's gain" value="+Rs 51,244" delta="+0.59%" deltaUp={true}/>
        <MetricCard label="Annual return" value="+12.3%" delta="vs 8.1% benchmark" deltaUp={true}/>
        <MetricCard label="Cash position" value="Rs 5.85 lac" delta="6.7% of portfolio"/>
      </div>
      <div style={grid(2)}>
        <Card title="Holdings">
          {HOLDINGS.map(h=>(
            <div key={h.ticker} style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"8px 0",borderBottom:"0.5px solid var(--border-light)"}}>
              <div><div style={{fontSize:13,fontWeight:500}}>{h.ticker}</div><div style={{fontSize:11,color:"var(--text-secondary)"}}>{h.name}</div></div>
              <div style={{fontSize:12,color:"var(--text-secondary)"}}>{h.alloc}</div>
              <div style={{textAlign:"right"}}><div style={{fontSize:13,fontWeight:500}}>{fmt(h.valuePkr)}</div><div style={{fontSize:11,color:h.up?"#0F6E56":"#A32D2D"}}>{h.delta}</div></div>
            </div>
          ))}
        </Card>
        <Card title="Allocation"><div style={{height:200,marginTop:8}}><canvas id="allocChart"/></div></Card>
      </div>
    </>
  );
}

function AIInsights({ transactions, spent }) {
  const [messages, setMessages] = useState([{ role:"ai", text:"Assalam-o-Alaikum! I'm your AI financial advisor. Ask me anything about your PKR finances, investments, or savings goals." }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);

  useEffect(()=>{ endRef.current?.scrollIntoView({behavior:"smooth"}); }, [messages]);

  const totalSpend = Object.values(spent).reduce((a,b)=>a+b,0);
  const systemPrompt = `You are a personal finance advisor for a user in Pakistan. All amounts are in Pakistani Rupees (PKR). Use Pakistani financial context (PSX stocks, NSS, mutual funds, Roshan Digital Account, savings accounts, SBP policy rates) when relevant. Be concise (2–4 sentences), specific, and actionable. No markdown formatting. User's June 2026 finances: total monthly spend Rs ${Math.round(totalSpend).toLocaleString()}, by category: ${JSON.stringify(Object.fromEntries(Object.keys(spent).map(k=>[k,Math.round(spent[k])])))}. Investments portfolio Rs 87 lac (+4.2% MTD). Net worth Rs 1.35 crore (+41.5% YoY). Savings rate 22%. Exchange rate: 1 USD = 278.5 PKR.`;

  async function send() {
    const text = input.trim();
    if (!text || loading) return;
    setInput("");
    const newMsgs = [...messages, { role:"user", text }];
    setMessages(newMsgs);
    setLoading(true);
    try {
      const res = await fetch("/api/chat", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          system: systemPrompt,
          messages: newMsgs.filter(m=>m.role!=="ai"||m!==messages[0]).map(m=>({ role:m.role==="ai"?"assistant":"user", content:m.text }))
        })
      });
      const data = await res.json();
      setMessages(prev=>[...prev,{ role:"ai", text: data.reply || "Sorry, I could not get a response." }]);
    } catch {
      setMessages(prev=>[...prev,{ role:"ai", text:"Connection error. Please try again." }]);
    }
    setLoading(false);
  }

  const quickBtns = [
    ["How can I reduce my food spending in Pakistan?","Reduce food spend ↗"],
    ["What investments should I consider in Pakistan — PSX, mutual funds, or NSS?","Pakistan investment ideas ↗"],
    ["Am I on track to save Rs 30 lac by December?","Savings goal check ↗"],
    ["Summarize my financial health this month in PKR","Monthly summary ↗"],
  ];

  return (
    <>
      <div style={grid(4)}>
        <MetricCard label="Insight score" value="82/100" delta="Good financial health" deltaUp={true}/>
        <MetricCard label="Savings potential" value="+Rs 94,690/mo" delta="Based on spending"/>
        <MetricCard label="Next review" value="Jul 1" delta="Monthly check-in"/>
        <MetricCard label="Goal progress" value="68%" delta="Emergency fund" deltaUp={true}/>
      </div>
      <div style={{background:"var(--bg-primary)",border:"0.5px solid var(--border-light)",borderRadius:"var(--radius-lg)",overflow:"hidden"}}>
        <div style={{padding:"1rem 1.25rem",borderBottom:"0.5px solid var(--border-light)",display:"flex",alignItems:"center",gap:8}}>
          <span style={{fontSize:18}}>🤖</span>
          <span style={{fontSize:14,fontWeight:500}}>Financial advisor</span>
          <span style={{fontSize:10,padding:"2px 7px",borderRadius:20,background:"#E1F5EE",color:"#0F6E56",fontWeight:500}}>AI-powered · PKR</span>
        </div>
        <div style={{padding:"1rem 1.25rem",display:"flex",flexDirection:"column",gap:10,maxHeight:280,overflowY:"auto"}}>
          {messages.map((m,i)=>(
            <div key={i} style={{padding:"10px 12px",borderRadius:"var(--radius-md)",fontSize:13,lineHeight:1.55,maxWidth:"88%",background:m.role==="ai"?"var(--bg-secondary)":"#1D9E75",color:m.role==="ai"?"var(--text-primary)":"#fff",alignSelf:m.role==="ai"?"flex-start":"flex-end"}}>
              {m.text}
            </div>
          ))}
          {loading && (
            <div style={{padding:"10px 12px",borderRadius:"var(--radius-md)",background:"var(--bg-secondary)",alignSelf:"flex-start",display:"flex",gap:4}}>
              {[0,.2,.4].map((d,i)=><span key={i} style={{width:6,height:6,borderRadius:"50%",background:"var(--text-secondary)",display:"inline-block",animation:`pulse 1.2s ${d}s infinite`}}>.</span>)}
            </div>
          )}
          <div ref={endRef}/>
        </div>
        <div style={{padding:"0.75rem 1.25rem",borderTop:"0.5px solid var(--border-light)",display:"flex",gap:8}}>
          <input style={{...inputStyle,flex:1}} placeholder="Ask about your finances in PKR..." value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&send()}/>
          <Btn primary onClick={send}>Send</Btn>
        </div>
      </div>
      <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
        {quickBtns.map(([q,label])=>(
          <Btn key={label} onClick={()=>{ setInput(q); setTimeout(send,50); }}>{label}</Btn>
        ))}
      </div>
      <style>{`@keyframes pulse{0%,60%,100%{opacity:.3}30%{opacity:1}}`}</style>
    </>
  );
}

function ExportView({ transactions }) {
  function exportTx() {
    const hdr = "date,description,category,amount_pkr,type\n";
    const body = transactions.map(t=>`${t.date},"${t.name}","${t.cat}",${Math.round(t.amount)},expense`).join("\n");
    downloadCSV("transactions_pkr.csv", hdr + body);
  }
  function exportNW() {
    const hdr = "month,net_worth_pkr,investments_pkr,cash_pkr,monthly_change_pkr\n";
    const body = NW_LABELS.map((l,i)=>{
      const ch = i===0?0:NW_PKR[i]-NW_PKR[i-1];
      return `${l},${NW_PKR[i]},${INV_PKR[i]},${CASH_PKR[i]},${ch>=0?"+":""}${Math.round(ch)}`;
    }).join("\n");
    downloadCSV("networth_timeline_pkr.csv", hdr + body);
  }
  function exportBudget() {
    const hdr = "category,budget_limit_pkr,amount_spent_pkr,remaining_pkr,pct_used\n";
    const body = Object.keys(BUDGET_LIMITS).map(cat=>{
      const lim=BUDGET_LIMITS[cat], sp=0;
      const pct=Math.round(sp/lim*1000)/10;
      return `"${cat}",${Math.round(lim)},${Math.round(sp)},${Math.round(lim-sp)},${pct}%`;
    }).join("\n");
    downloadCSV("budget_report_pkr.csv", hdr + body);
  }
  function exportHoldings() {
    const hdr = "ticker,name,allocation,value_pkr,daily_change\n";
    const body = HOLDINGS.map(h=>`${h.ticker},"${h.name}",${h.alloc},${Math.round(h.valuePkr)},${h.delta}`).join("\n");
    downloadCSV("holdings_pkr.csv", hdr + body);
  }
  function exportAll() {
    [exportTx, exportNW, exportBudget, exportHoldings].forEach((fn,i)=>setTimeout(fn,i*300));
  }

  const ExCard = ({ title, badge, badgeColor, desc, preview, onExport, filename }) => (
    <div style={{background:"var(--bg-primary)",border:"0.5px solid var(--border-light)",borderRadius:"var(--radius-lg)",padding:"1.25rem"}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"1rem"}}>
        <span style={{fontSize:14,fontWeight:500}}>{title}</span>
        <span style={{fontSize:11,padding:"3px 8px",borderRadius:20,fontWeight:500,background:badgeColor+"22",color:badgeColor}}>{badge}</span>
      </div>
      <p style={{fontSize:13,color:"var(--text-secondary)",marginBottom:14}}>{desc}</p>
      {preview && <div style={{background:"var(--bg-secondary)",borderRadius:"var(--radius-md)",padding:"10px 12px",fontSize:12,fontFamily:"var(--mono)",color:"var(--text-secondary)",marginBottom:14,overflowX:"auto",whiteSpace:"nowrap"}}>{preview}</div>}
      <Btn export onClick={onExport}>⬇ Download {filename}</Btn>
    </div>
  );

  return (
    <>
      <div style={grid(4)}>
        <MetricCard label="Transactions" value={transactions.length} delta="Ready to export"/>
        <MetricCard label="Net worth records" value="24" delta="24 months of data"/>
        <MetricCard label="Budget categories" value="6" delta="Categories tracked"/>
        <MetricCard label="Holdings" value="6" delta="Investment positions"/>
      </div>
      <ExCard title="Export transactions" badge="CSV · PKR" badgeColor="#1D9E75"
        desc="All transactions with date, category, and amount in PKR."
        preview={<>date,description,category,amount_pkr,type<br/>2026-06-17,Grocery run,Food & dining,17880,expense<br/><span style={{color:"var(--text-tertiary)"}}>… +{transactions.length-1} more rows</span></>}
        onExport={exportTx} filename="transactions_pkr.csv"/>
      <ExCard title="Export net worth timeline" badge="CSV · PKR" badgeColor="#185FA5"
        desc="24-month net worth history with investments, cash, and monthly change — all in PKR."
        preview={<>month,net_worth_pkr,investments_pkr,cash_pkr,monthly_change_pkr<br/>Jul-24,9513990,5349200,2255850,+345540<br/><span style={{color:"var(--text-tertiary)"}}>… +22 more rows</span></>}
        onExport={exportNW} filename="networth_timeline_pkr.csv"/>
      <ExCard title="Export budget report" badge="CSV · PKR" badgeColor="#BA7517"
        desc="Monthly budget vs. actual spending by category in PKR."
        onExport={exportBudget} filename="budget_report_pkr.csv"/>
      <ExCard title="Export holdings" badge="CSV · PKR" badgeColor="#1D9E75"
        desc="Portfolio positions with PKR values and performance."
        onExport={exportHoldings} filename="holdings_pkr.csv"/>
      <div style={{background:"var(--bg-primary)",border:"0.5px solid var(--border-light)",borderRadius:"var(--radius-lg)",padding:"1.25rem"}}>
        <div style={{fontSize:14,fontWeight:500,marginBottom:8}}>Export everything</div>
        <p style={{fontSize:13,color:"var(--text-secondary)",marginBottom:14}}>Download all four datasets as separate CSV files in one go.</p>
        <Btn primary onClick={exportAll}>⬇ Download all CSV files</Btn>
      </div>
    </>
  );
}

// ── Primitives ────────────────────────────────────────────────────────────────
const inputStyle = { padding:"0.45rem 0.75rem", border:"0.5px solid var(--border)", borderRadius:"var(--radius-md)", fontSize:13, background:"var(--bg-primary)", color:"var(--text-primary)", width:"100%" };
const Input = (props) => <input style={inputStyle} {...props}/>;
const Label = ({children}) => <div style={{fontSize:12,color:"var(--text-secondary)",marginBottom:4}}>{children}</div>;
const grid = (cols) => ({ display:"grid", gridTemplateColumns:`repeat(${cols},minmax(0,1fr))`, gap:12 });

function Btn({ children, onClick, primary, export:isExport, small }) {
  return (
    <button onClick={onClick} style={{
      display:"inline-flex", alignItems:"center", gap:6,
      padding: small ? "3px 8px" : "0.4rem 0.85rem",
      fontSize: small ? 12 : 13,
      borderRadius:"var(--radius-md)",
      border: `0.5px solid ${primary?"#1D9E75":isExport?"#185FA5":"var(--border)"}`,
      background: primary?"#1D9E75": isExport?"#185FA5":"var(--bg-primary)",
      color: primary||isExport?"#fff":"var(--text-primary)",
      cursor:"pointer", fontFamily:"var(--font)"
    }}>{children}</button>
  );
}

function Card({ title, action, badge, badgeColor, badgeBg, children }) {
  return (
    <div style={{background:"var(--bg-primary)",border:"0.5px solid var(--border-light)",borderRadius:"var(--radius-lg)",padding:"1.25rem"}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"1rem"}}>
        <span style={{fontSize:14,fontWeight:500}}>{title}</span>
        {badge && <span style={{fontSize:11,padding:"3px 8px",borderRadius:20,fontWeight:500,background:badgeBg,color:badgeColor}}>{badge}</span>}
        {action}
      </div>
      {children}
    </div>
  );
}

// ── App Shell ─────────────────────────────────────────────────────────────────
const NAV = [
  { id:"dashboard",  label:"Dashboard",   icon:"📊", section:"Overview" },
  { id:"networth",   label:"Net worth",   icon:"📈", section:"Overview" },
  { id:"expenses",   label:"Expenses",    icon:"🧾", section:"Overview" },
  { id:"budget",     label:"Budgets",     icon:"⚙️", section:"Overview" },
  { id:"investments",label:"Investments", icon:"💹", section:"Grow" },
  { id:"insights",   label:"AI insights", icon:"✨", section:"Grow" },
  { id:"export",     label:"Export CSV",  icon:"⬇️", section:"Data" },
];

export default function Home() {
  const [view, setView] = useState("dashboard");
  const [transactions, setTransactions] = useState(INIT_TX);
  const [syncing, setSyncing] = useState(false);
  const spent = calcSpent(transactions);

  function syncData() {
    setSyncing(true);
    setTimeout(() => setSyncing(false), 1400);
  }

  const sections = [...new Set(NAV.map(n=>n.section))];
  const currentLabel = NAV.find(n=>n.id===view)?.label || "Dashboard";

  return (
    <>
      <Head>
        <title>Fintab · Personal Finance PKR</title>
        <meta name="description" content="Personal finance dashboard in Pakistani Rupees with AI advisor, net worth timeline, budget tracking and CSV export."/>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="icon" href="/favicon.ico"/>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@2.44.0/tabler-icons.min.css"/>
      </Head>
      <Script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js" strategy="beforeInteractive"/>

      <div style={{display:"flex",height:"100vh",minHeight:620,background:"var(--bg-tertiary)"}}>
        {/* Sidebar */}
        <aside style={{width:220,flexShrink:0,background:"var(--bg-primary)",borderRight:"0.5px solid var(--border)",display:"flex",flexDirection:"column",padding:"1rem 0"}}>
          <div style={{padding:"0.5rem 1.25rem 1.25rem",fontSize:15,fontWeight:500,display:"flex",alignItems:"center",gap:8}}>
            <div style={{width:28,height:28,borderRadius:8,background:"#1D9E75",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontSize:15}}>🌿</div>
            Fintab · PKR
          </div>
          {sections.map(sec=>(
            <div key={sec}>
              <div style={{fontSize:10,fontWeight:500,color:"var(--text-tertiary)",letterSpacing:".08em",padding:"1rem 1.25rem 0.35rem",textTransform:"uppercase"}}>{sec}</div>
              {NAV.filter(n=>n.section===sec).map(n=>(
                <button key={n.id} onClick={()=>setView(n.id)} style={{display:"flex",alignItems:"center",gap:9,padding:"0.55rem 1.25rem",fontSize:13.5,color:view===n.id?"#0F6E56":"var(--text-secondary)",cursor:"pointer",border:"none",background:view===n.id?"var(--bg-secondary)":"none",width:"100%",textAlign:"left",fontWeight:view===n.id?500:400}}>
                  <span>{n.icon}</span> {n.label}
                </button>
              ))}
            </div>
          ))}
          <div style={{marginTop:"auto",padding:"1rem 1.25rem"}}>
            <div style={{fontSize:11,color:"var(--text-tertiary)",marginBottom:4}}>Exchange rate</div>
            <div style={{fontSize:12,color:"var(--text-secondary)",fontWeight:500}}>1 USD = 278.5 PKR</div>
            <div style={{display:"flex",alignItems:"center",gap:7,fontSize:12,color:"var(--text-secondary)",marginTop:8}}>
              <div style={{width:7,height:7,borderRadius:"50%",background:syncing?"#BA7517":"#1D9E75",transition:"background .3s"}}/>
              {syncing?"Syncing…":"Synced just now"}
            </div>
          </div>
        </aside>

        {/* Main */}
        <main style={{flex:1,overflowY:"auto",display:"flex",flexDirection:"column"}}>
          <div style={{padding:"1rem 1.5rem",background:"var(--bg-primary)",borderBottom:"0.5px solid var(--border)",display:"flex",alignItems:"center",justifyContent:"space-between",flexShrink:0}}>
            <div style={{fontSize:16,fontWeight:500}}>{currentLabel}</div>
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <Btn onClick={syncData}>🔄 Sync</Btn>
              <Btn isExport onClick={()=>setView("export")}>⬇ Export</Btn>
              <Btn primary onClick={()=>setView("expenses")}>+ Add expense</Btn>
            </div>
          </div>
          <div style={{padding:"1.5rem",flex:1,display:"flex",flexDirection:"column",gap:"1.25rem"}}>
            {view==="dashboard"   && <Dashboard transactions={transactions} spent={spent} goTo={setView}/>}
            {view==="networth"    && <NetWorth/>}
            {view==="expenses"    && <Expenses transactions={transactions} setTransactions={setTransactions}/>}
            {view==="budget"      && <Budget spent={spent}/>}
            {view==="investments" && <Investments/>}
            {view==="insights"    && <AIInsights transactions={transactions} spent={spent}/>}
            {view==="export"      && <ExportView transactions={transactions}/>}
          </div>
        </main>
      </div>
    </>
  );
}
